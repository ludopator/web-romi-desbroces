import CoverageSection from "../CoverageSection";

export default function CoverageSectionExample() {
  return <CoverageSection />;
}
