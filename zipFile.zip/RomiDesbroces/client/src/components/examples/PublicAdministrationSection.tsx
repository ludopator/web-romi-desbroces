import PublicAdministrationSection from "../PublicAdministrationSection";

export default function PublicAdministrationSectionExample() {
  return <PublicAdministrationSection />;
}
