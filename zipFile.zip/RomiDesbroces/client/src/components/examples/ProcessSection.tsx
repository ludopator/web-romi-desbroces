import ProcessSection from "../ProcessSection";

export default function ProcessSectionExample() {
  return <ProcessSection />;
}
